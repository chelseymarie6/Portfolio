# Portfolio

### This is my portfolio showcasing some of my favorite projects I've worked on. 

https://chelseymarie6.github.io/Portfolio/

![Screenshot](/img/portfolio.PNG)